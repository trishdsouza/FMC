package com.freedommortgage.authorizationserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
