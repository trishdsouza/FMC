package com.freedommortgage.authorizationserver.Config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;

@Configuration
@EnableAuthorizationServer
public class AuthServerConfig extends AuthorizationServerConfigurerAdapter {
    @Value("${user.oauth.clientId}")
    private String ClientID;
    @Value("${user.oauth.clientSecret}")
    private String ClientSecret;
    @Value("${user.oauth.redirectUris}")
    private String RedirectURL;

    private final PasswordEncoder passwordEncoder;
//    private AuthenticationManager authenticationManager;

//    @Autowired
//    public AuthServerConfig(PasswordEncoder passwordEncoder, AuthenticationManager authenticationManager) {
//        this.passwordEncoder = passwordEncoder;
//        this.authenticationManager = authenticationManager;
//    }

    public AuthServerConfig(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }


    @Override
    public void configure(AuthorizationServerSecurityConfigurer oauthServer) throws Exception {
        oauthServer.tokenKeyAccess("permitAll()")
                .checkTokenAccess("isAuthenticated()");
    }

//    @Override
//    public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
//        //@formatter:off
//        endpoints
//                .tokenStore(tokenStore())
//                .accessTokenConverter(accessTokenConverter()) // added for JWT
//                .authenticationManager(authenticationManager);
//        //
//    }
//
//    // A token store bean. JWT token store
//    @Bean
//    public TokenStore tokenStore() {
//        return new JwtTokenStore(accessTokenConverter()); // For JWT. Use in-memory, jdbc, or other if not JWT
//    }
//
//    // Token converter. Needed for JWT
//    @Bean
//    public JwtAccessTokenConverter accessTokenConverter() {
//        JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
//        //String jws = secretService.getSecrets();
//        converter.setSigningKey("123"); // symmetric key
//        return converter;
//    }
//
//    // Token services. Needed for JWT
//    @Bean
//    @Primary
//    public DefaultTokenServices tokenServices() {
//        DefaultTokenServices defaultTokenServices = new DefaultTokenServices();
//        defaultTokenServices.setTokenStore(tokenStore());
//        return defaultTokenServices;
//    }
//
//    /** End of JWT config */

    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        clients.inMemory()
                .withClient(ClientID)
                .secret(passwordEncoder.encode(ClientSecret))
                .authorizedGrantTypes("password", "authorization_code", "implicit", "client_credentials", "refresh_token")
                .scopes("ROLE_USER", "ROLE_MANAGER", "ROLE_ADMIN")
                .autoApprove(true)
                .accessTokenValiditySeconds(112300)
                .refreshTokenValiditySeconds(240000)
                .redirectUris(RedirectURL);
    }
}
