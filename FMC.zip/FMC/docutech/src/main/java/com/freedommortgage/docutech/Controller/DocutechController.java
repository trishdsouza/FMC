package com.freedommortgage.docutech.Controller;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

@RestController
public class DocutechController {

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public String hello(Principal principal) {

        return "Hello " + principal.getName() + "!!!";
    }

    @RequestMapping(value = "/secured", method = RequestMethod.GET)
    public String securedResource(Authentication auth) {
        return "This is a SECURED resource. Authentication: " + auth.getName() + "; Authorities: " + auth.getAuthorities();
    }

    @RequestMapping(value = "/unsecured", method = RequestMethod.GET)
    public String unsecuredResource() {
        return "This is an unsecured resource";
    }

}
