package com.freedommortgage.docutech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocutechApplicationTests {

	@Test
	void contextLoads() {
	}

}
